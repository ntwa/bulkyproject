Requirements :-

1. Apache Web Server
2. PHP
3. MySQL
4. Web Browser

Demo of this Application :- https://youtu.be/ZfaNJDuDQO4

Developed by :- Suraj Mundalik (suraj-mundalik.info)
